<?php
/* Sean Emo
WEBD 3201
Sept 28, 2020
*/

			include("./includes/header.php");
	?>
  <?php
  unset($_SESSION['user']);
  session_destroy($_SESSION['user']);
	session_start();
  setMessage("You have successfully logged out, have a great day!");
  redirect("./sign-in.php")

  ?>

	<?php include("./includes/footer.php"); ?>
