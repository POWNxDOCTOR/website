--Sean Emo
--September 28, 2020
--WEBD 3201
CREATE EXTENSION IF NOT EXISTS pgcrypto;

DROP TABLE IF EXISTS calls;
CREATE TABLE calls(
  FirstName VARCHAR(128),
  LastName VARCHAR(128),
  PhoneNumber VARCHAR(11),
  TimeofCall TIMESTAMP,
  SalesEmail VARCHAR(255)
  FOREIGN KEY (SalesEmail) REFERENCES salespeople (EmailAddress)
);

INSERT INTO calls (FirstName, LastName, PhoneNumber, TimeofCall)
VALUES( 'Naruto', 'Uzumaki', 'greatesthokage@dcmail.ca', '5198067760', '2001');

INSERT INTO calls (FirstName, LastName, PhoneNumber, TimeofCall)
VALUES( 'Izuku', 'Midoriya', 'iloveallmight@heroes.ca', '4165503408', '4503');

INSERT INTO calls (FirstName, LastName, PhoneNumber, TimeofCall)
VALUES( 'Monkey', 'Luffy', 'pirateking@outlaw.gov', '3102245609', '2099');
