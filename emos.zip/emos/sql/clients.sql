--Sean Emo
--September 28, 2020
--WEBD 3201
CREATE EXTENSION IF NOT EXISTS pgcrypto;

DROP TABLE IF EXISTS clients;
CREATE TABLE clients(
  EmailAddress VARCHAR(255) UNIQUE,
  FirstName VARCHAR(128),
  LastName VARCHAR(128),
  PhoneNumber VARCHAR(11),
  ExtensionNum INT,

);

INSERT INTO clients (FirstName, LastName, EmailAddress, PhoneNumber, ExtensionNum)
VALUES( 'Naruto', 'Uzumaki', 'greatesthokage@dcmail.ca', '5198067760', '2001');

INSERT INTO clients (FirstName, LastName, EmailAddress, PhoneNumber, ExtensionNum)
VALUES( 'Izuku', 'Midoriya', 'iloveallmight@heroes.ca', '4165503408', '4503');

INSERT INTO clients (FirstName, LastName, EmailAddress, PhoneNumber, ExtensionNum)
VALUES( 'Monkey', 'Luffy', 'pirateking@outlaw.gov', '3102245609', '2099');
