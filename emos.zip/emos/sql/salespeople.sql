--Sean Emo
--September 28, 2020
--WEBD 3201
CREATE EXTENSION IF NOT EXISTS pgcrypto;

DROP TABLE IF EXISTS salespeople;
CREATE TABLE salespeople(
  EmailAddress VARCHAR(255) UNIQUE,
  Password VARCHAR(255) NOT NULL,
  FirstName VARCHAR(128),
  LastName VARCHAR(128),
  LastAccess TIMESTAMP,
  EnrolDate TIMESTAMP,
  Enable BOOLEAN,
  Type VARCHAR(2),
  PRIMARY KEY(EmailAddress)
);

INSERT INTO salespeople (FirstName, LastName, EmailAddress, Password, LastAccess, EnrolDate, Enable, Type)
VALUES( 'Costa', 'Kokkotas', 'ckokkotas@dcmail.ca', crypt('costasmells', gen_salt('bf')), '2020-06-22 19:10:25',
'2020-08-22 11:11:11', true, 'a');

INSERT INTO salespeople (FirstName, LastName, EmailAddress, Password, LastAccess, EnrolDate, Enable, Type)
VALUES( 'Sasuke', 'Ichiha', 'leafhero@dcmail.ca', crypt('ilovesasuke', gen_salt('bf')), '2020-06-22 19:10:25',
'2020-08-22 11:11:11', true, 'a');

INSERT INTO salespeople (FirstName, LastName, EmailAddress, Password, LastAccess, EnrolDate, Enable, Type)
VALUES( 'Gon', 'Freecs', 'huntersrus@dcmail.ca', crypt('killua', gen_salt('bf')), '2020-06-22 19:10:25',
'2020-08-22 11:11:11', true, 'a');

SELECT * FROM salespeople;
