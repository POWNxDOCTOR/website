<?php
/* Sean Emo
WEBD 3201
Sept 28, 2020
*/
// Functions.php

function DisplayCopyrightInfo()
{
    echo "&copy;", date('Y'), " Sean Emo";
}
// Function to redirect web pages
function redirect($url)
{
  header("Location:".$url);
  ob_flush();
}

function setMessage($msg)
{
  $_SESSION['message'] = $msg;
}

function getMessage()
{
  return $_SESSION['message'];
}

function isMessage()
{
 return isset($_SESSION['message'])?true:false;
}

function removeMessage()
{
  unset($_SESSION['message']);
}

function flashMessage()
{
  $message = "";
  if(isMessage())
  {
    $message = getMessage();
    removeMessage();
  }
  return $message;
}
function dump($arg)
{
  echo "<pre>";
  print_r($arg);
  echo "<pre>";
}

?>
