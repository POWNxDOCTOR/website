<?php
/* Sean Emo
WEBD 3201
Sept 28, 2020
*/

/**********Cookies*********/
define("COOKIE LIFESPAN", "2592000");

/**********User Types*********/
define("ADMIN", 'a');


/**********Database Constants*********/
define("DB_HOST", "127.0.0.1");
define("DATABASE", "emos_db");
define("DB_ADMIN", "emos");
define("DB_PORT", "5432");
define("DB_PASSWORD", "100761183");
define("MINIMUM_ID_LENGTH", 5);
define("MAXIMUM_ID_LENGTH", 20);
define("MINIMUM_PASSWORD_LENGTH", 6);
define("MAXIMUM_PASSWORD_LENGTH", 15);
define("MAX_FIRST_NAME_LENGTH", 20);
define("MAX_LAST_NAME_LENGTH", 30);
define("MAXIMUM_EMAIL_LENGTH", 255);
define("MAXIMUM_NAME_LENGTH", 30);
define("PHONE_NUMBER_LENNGTH", 10);
?>
