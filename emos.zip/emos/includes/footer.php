<?php /* Sean Emo
WEBD 3201
Sept 28, 2020
*/ ?>
                </div>
            <footer>
              <?php
                  echo DisplayCopyrightInfo();
              ?>
            </footer>
        </main>
       </div>
    </div>
  </body>
</html>
