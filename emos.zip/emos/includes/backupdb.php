<?php
/* Sean Emo
WEBD 3201
Sept 28, 2020
*/
// can i just put this function in function.php?
function db_connect()
  {
//    return pg_connect("host=127.0.0.1 dbname=emos_db user=emos password=100761183");
      return pg_connect("host=".DB_HOST." port=".DB_PORT." dbname=".DATABASE." user=".DB_ADMIN." password=".DB_PASSWORD);
  }

$conn = db_connect();

function user_select()
{
  $conn = db_connect();
  $user_select_stmt = pg_prepare($conn,"user_select", "SELECT * FROM users WHERE email_address = $1");
  $user_select_all_stmt = pg_prepare($conn,"user_select_all", "SELECT * FROM users");
  $result = pg_execute($conn, "user_select", array("jdoe@dcmail.ca"));
  if(pg_num_rows($result) == 1)
    {
      $user = pg_fetch_assoc($result, 0);
      dump($user);
      $is_user = password_verify("some_password", $user["password"]);
      echo "Is user authenticated: " .$is_user. "<br/>";
    }
}

function authenticate_login($email, $plain_password)
{
    $conn = db_connect();
    $user_select = pg_prepare($conn, "user_select"," SELECT * FROM users WHERE emailaddress = $1");
    $result = pg_execute($conn,"user_select", array($email));
    $user = pg_fetch_assoc($result,0);
    print_r($user);
    if(password_verify($plain_password, $user['password']))
    {
      setMessage("User successfully logged in!");
      $_SESSION['user'] = $user;
      redirect("dashboard.php");
    }
    else
    {
      setMessage("Authentication failed: Please try again!");
      redirect("sign-in.php");
    }
}
?>
