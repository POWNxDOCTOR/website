<?php
/* Sean Emo
WEBD 3201
Sept 28, 2020
*/
// can i just put this function in function.php?
function db_connect()
  {
//    return pg_connect("host=127.0.0.1 dbname=emos_db user=emos password=100761183");
      return pg_connect("host=".DB_HOST." port=".DB_PORT." dbname=".DATABASE." user=".DB_ADMIN." password=".DB_PASSWORD);
  }


$conn = db_connect();
$user_select_stmt = pg_prepare($conn,"user_select", "SELECT * FROM users WHERE emailaddress = $1");
$sales_select_all_stmt = pg_prepare($conn,"sales_select_all", "SELECT * FROM salespeople");
$sales_select = pg_prepare($conn,"sales_select", "SELECT EmailAddress FROM salespeople");
$sales_add_stmt = pg_prepare($conn, "sales_insert", 'INSERT INTO salespeople(FirstName, LastName,
EmailAddress, Password, LastAccess, EnrolDate, Enable, Type ) VALUES($1, $2, $3, $4, $5, $6, $7, $8)');
/*$call_add_stmt = pg_prepare($conn, "calls_insert",
'INSERT INTO calls(FirstName, LastName, EmailAddress, PhoneNumber, ExtensionNum,) VALUES($1, $2, $3, $4, $5)');
$client_add_stmt = pg_prepare($conn, "client_insert",
'INSERT INTO clients(FirstName, LastName, EmailAddress, PhoneNumber, ExtensionNum,) VALUES($1, $2, $3, $4, $5)');
*/
function user_select($email)
{
  $user = false;
  $conn = db_connect();
  $result = pg_execute($conn, "user_select", array($email));

  if (pg_num_rows($result) == 1)
  {
    $user = pg_fetch_assoc($result, 0);
  }

function salesperson_select($email)
{
  $conn = db_connect();
  $result = pg_execute($conn, "sales_select", array($email));
  $record = pg_num_rows($result);

  for($i=0; $i<$record; $i++)
  {
    $salesman = pg_fetch_assoc($result, $i, "EmailAddress");
    echo "<option> $salesman </option>";
  }
}

  return $user;
}

function user_authenticate($email, $plain_password)
{//fix this function
  $users = user_select($email);
  $login = false;

  if ($users != false)
  {
    if (password_verify($plain_password, $users["password"]))
    {
      $login = $users;
      setMessage("User successfully logged in!");
      $_SESSION['user'] = $user;
      redirect("dashboard.php");
    }
    else
    {
      setMessage("Authentication failed: Please try again!");
      redirect("sign-in.php");
    }
  }

  return $login;
}
//not built fully
/*function add_salesman()
{
  $conn = db_connect();
  if ($error = "")
  {
    pg_execute($conn, "sales_insert",  array($user) );
  }
}

function display_form()
{
  $output = "";
  $conn = db_connect();
  $person = value of array()

  foreach($user as $key => $value)
  echo "{key} => {value}";
  print_r($result);
}
*/
?>
