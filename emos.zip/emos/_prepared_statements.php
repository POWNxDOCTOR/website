<?php

require "./includes/constants.php";

function dump($arg)
{
  echo "<pre>";
  print_r($arg);
  echo "<pre>";
}

function db_connect()
{
  return pg_connect("host=".DB_HOST."port=".DB_PORT."dbname=".DATABASE."user=".DB_ADMIN."password=".DB_PASSWORD);
}
$conn = db_connect();

$user_select_stmt = pg_prepare($conn,"user_select", "SELECT * FROM users WHERE email_address = $1");
$user_select_all_stmt = pg_prepare($conn,"user_select_all", "SELECT * FROM users");

$result = pg_execute($conn, "user_select", array("jdoe@dcmail.ca"));

if(pg_num_rows($result) == 1)
{
  $user = pg_fetch_assoc($result, 0);
  dump($user);
  $is_user = password_verify("some_password", $user["password"]);
  echo "Is user authenticated: " .$is_user. "<br/>";
}


//$result = pg_execute($conn, "user_select_all", array());

/* if(pg_num_rows($result) > 0)
{
  for($i= 0; $i < pg_num_rows($result); $i++)
  {
  $user = pg_fetch_assoc($result, $i);
  dump($user);
  }
}
*/
/*
if($_SERVER["REQUEST_METHOD"] == "POST")
{
  $student_number = trim($_POST['number']);
  $first_name = trim($_POST['first']);
  $last_name = trim($_POST['last']);
  $check = trim($_POST['secret']);

  $today = date("Ymd");
  $now = date("Y-m-d G:i:s");

  $handle = fopen("./attendance/" .$today. ".txt", 'a');

  fwrite($handle, $now. "-" .$student_number." - " .$first_name. " " .$last_name.
  " " .$check. "\n");

  fclose($handle);
  $message .= $now. "-" .$student_number." - " .$first_name. " " .$last_name. " was
  added to the log <br/>";
  $message .="Click <a href=\"./file2.php\">here</a> to see who is in class";


  $message = "";
  $today = date("Ymd");

  $handle = fopen("./attendance/" .today. ".txt", 'r');

  while(!feof($handle))
  {
    $message .=fgets($handle, 1024);
    $message .= "<br /> \n";
  }
  fclose($handle);

  //
  $conn = db_connect();
  $stmt2 = pg_prepare($conn, 'user_retrieve', 'SELECT * FROM users WHERE id = $1');
  $login = trim($_POST['user_id']);
  $plain_password = trim($_POST['password']);

  $result3 = pg_execute($conn, 'user_retrieve', array($login));
  $user = pg_fetch_assoc($result3, 0);
  if(password_verify($plain_password, $user['password']))
  {
      $_SESSION['user'] = $user;
  }
  else
  {
  $message = "Did not authenticate, try again";
  }

  // Registration example

  $conn = db_connect();
  $stmt3 = pg_prepare($conn, 'user_insert', 'INSERT INTO users(Id, Password, FirstName, LastName,
  EmailAddress, LastAccess, EnrolDate, Enabled, Type) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)');
  $login = trim($_POST['password']);
  password = trim($_POST['password']);

  $result = pg_execute($conn, 'user_insert', array($login, password_hash($password, PASSWORD_BCRYPT), //finish this))

  //foreach example

  $user = array("name" => "Fred", "id" => "smithf", => "fred.smith@dmail.com");
  foreach ($user as $field => $data)
  {
    echo "User info: property is " .$field. " that stores the value " .$data. "<br/>";
  }

  // cookie example

  $value = 'something from somewhere';
  setcookie("TestCookie1", $value, time()+ COOKIE LIFESPAN);

  echo $_COOKIE["Test Cookie"];
  print_r($_COOKIE);

  //email filter example
  
  $error = ""; //an error message variable, initially empty
//embed in a page with an input box named 'email_address' and
//have the form submit here in POST mode
$email = trim($_POST['email_address']); //trim whitespace
if(strlen($email) == 0){
//use strlen() to det. whether the var empty or not
$error .= "You must enter an email address";
}else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
//note the ! not symbol, if valid no problem
$error .= "<em>". $email . "</em> is not a valid email address";
//NOTE: give the invalid address so user knows what they entered
$email = ""; //empty out the variable so it is not sticky
}

  */





}

?>
