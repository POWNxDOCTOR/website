<?php
/* Sean Emo
WEBD 3201
Sept 28, 2020
*/
			$title = " WEBD 3201 Home Page";
			$file = "index.php";
			$description = "This is the home page for WEBD 3201 for Sean Emo";
			$date = date("d-m-Y");
			$banner = "WEBD3201 - Lab 1";
			include("./includes/header.php");
			redirect("sign-in.php");


	?>



<h1 class="cover-heading">Cover your page.</h1>
<h2>	<?php echo $message;?>	 </h2>
<p class="lead">Cover is a one-page template for building simple and beautiful home pages. Download, edit the text, and add your own fullscreen background photo to make it your own.</p>
<p class="lead">
    <a href="#" class="btn btn-lg btn-secondary">Learn more</a>
</p>

<?php
include "./includes/footer.php";
?>
