<?php
/* Sean Emo
WEBD 3201
October 22, 2020
*/
			$title = "Clients";
			$file = "calls.php";
			$description = "This is the clients page that contains all of the salespeople in the database";
			$date = date("d-m-Y");
			$banner = "WEBD2201 - Lab 2 - User Registration/Update";
			include("./includes/header.php");
	?>

  <?php
  // variable declaration

  $first_name ="";
  $last_name= "";
  $error="";

	if($_SERVER["REQUEST_METHOD"] == "GET")
	{
    $first_name = ""; 
		$last_name = "";
    $phoneNum = "";
	}
	elseif($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$error = "";
		$first_name = trim($_POST["first_name"]);
		$last_name = trim($_POST["last_name"]);
    $phoneNum = trim($_POST["phone_number"]);
    $today = date("Y-m-d",time());
	}
  ?>

  <h3> <?php echo $error; ?> </h3>

	<form class="form-signin" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
	<h1 class="h3 mb-3 font-weight-normal">Please fill out the call log</h1>
	<label for="inputFirst" class="sr-only">First Name</label>
	<input type="firstname" id="inputFirst" name="first_name" class="form-control" placeholder="First Name" required>
  <label for="inputLast" class="sr-only">Last Name</label>
	<input type="lastname" id="inputLast" name="last_name" class="form-control" placeholder="Last Name" required>
  <label for="inputPhone" class="sr-only">Phone Number</label>
  <input type="phonenumber" id="inputPhone" name="phone_number" class="form-control" placeholder="Phone Number" required>
	<button class="btn btn-lg btn-primary btn-block" type="submit">Add to Call Log</button>
	</form>

  <?php
  include "./includes/footer.php";
  ?>
