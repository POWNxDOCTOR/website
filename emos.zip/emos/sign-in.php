<?php
/* Sean Emo
WEBD 3201
Sept 28, 2020
*/
			$title = " WEBD 3201 Log-in Page";
			$file = "sign-in.php";
			$description = "This is the log-in page for WEBD 3201 for Sean Emo";
			$date = date("d-m-Y");
			$banner = "WEBD3201 - Log-in Page";
			include("./includes/header.php");

	?>

<h2>	<?php echo $message; ?>	 </h2>
<?php

// variable declaration

$password = "";
$email="";

if($_SERVER["REQUEST_METHOD"] == "GET")
{

  $password = "";
  $email="";

}
elseif($_SERVER["REQUEST_METHOD"] == "POST")
{
		$email = trim($_POST["inputEmail"]);
    $password = trim($_POST["inputPassword"]);
		user_authenticate($email,$password);
}
?>
		<form class="form-signin" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
    <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
    <label for="inputEmail" class="sr-only">Email address</label>
    <input type="email" id="inputEmail" name="inputEmail" class="form-control" placeholder="Email address" required autofocus>
    <label for="inputPassword" class="sr-only">Password</label>
    <input type="password" id="inputPassword" name="inputPassword" class="form-control" placeholder="Password" required>
    <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
</form>

<?php
include "./includes/footer.php";
?>
