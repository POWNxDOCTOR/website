<?php
/* Sean Emo
WEBD 3201
October 22, 2020
*/
			$title = "Salespeople";
			$file = "salespeople.php";
			$description = "This is the salespeople page that contains all of the salespeople in the database";
			$date = date("d-m-Y");
			$banner = "WEBD2201 - Lab 2 - User Registration/Update";
			include("./includes/header.php");
	?>
  <?php
  // variable declaration

  $password = "";
  $first_name ="";
  $last_name= "";
  $email="";
  $error="";



	if($_SERVER["REQUEST_METHOD"] == "GET")
	{

	  $password = "";
	  $email="";

	}
	elseif($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$error = "";
		$password = trim($_POST["password"]);
		$first_name = trim($_POST["first_name"]);
		$last_name = trim($_POST["last_name"]);
		$email = trim($_POST["email_address"]);
	}
	//echo display_form();
  ?>

  <h3> <?php echo $error; ?> </h3>

	<form class="form-signin" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
	<h1 class="h3 mb-3 font-weight-normal">Please fill out the form</h1>
	<label for="inputFirst" class="sr-only">First Name</label>
	<input type="firstname" id="inputFirst" name="first_name" class="form-control" placeholder="First Name" required>
	<label for="inputLast" class="sr-only">Last Name</label>
	<input type="lastname" id="inputLast" name="last_name" class="form-control" placeholder="Last Name" required>
	<label for="inputEmail" class="sr-only">Email address</label>
	<input type="email" id="inputEmail" name="email_address" class="form-control" placeholder="Email address" required autofocus>
	<label for="inputPassword" class="sr-only">Password</label>
	<input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>
	<button class="btn btn-lg btn-primary btn-block" type="submit">Add to Database</button>
	</form>

  <?php
  include "./includes/footer.php";
  ?>
